package com.perisic.banana.peripherals;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class AchievementsGUI extends JFrame {

    private static final long serialVersionUID = 1L;

    public AchievementsGUI(ArrayList<String> achievements, String playerName) {
        super("Achievements - " + playerName);
        initUI(achievements, playerName);
    }

    private void initUI(ArrayList<String> achievements, String playerName) {
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window

        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, new Color(240, 128, 128), 0, getHeight(), new Color(255, 182, 193));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setOpaque(false);

        JLabel headerLabel = new JLabel("Achievements");
        headerLabel.setFont(new Font("Roboto", Font.BOLD, 28));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Achievements Display Panel
        JPanel achievementsPanel = new JPanel();
        achievementsPanel.setOpaque(false);
        achievementsPanel.setLayout(new BoxLayout(achievementsPanel, BoxLayout.Y_AXIS));
        achievementsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        if (achievements.isEmpty()) {
            JLabel noAchievementsLabel = new JLabel("No achievements unlocked yet.");
            noAchievementsLabel.setFont(new Font("Roboto", Font.PLAIN, 16));
            noAchievementsLabel.setForeground(Color.WHITE);
            noAchievementsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            achievementsPanel.add(noAchievementsLabel);
        } else {
            for (String achievement : achievements) {
                JLabel achievementLabel = new JLabel("\u2605 " + achievement);
                achievementLabel.setFont(new Font("Roboto", Font.PLAIN, 18));
                achievementLabel.setForeground(Color.WHITE);
                achievementLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                achievementsPanel.add(achievementLabel);
                achievementsPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacing
            }
        }

        JScrollPane scrollPane = new JScrollPane(achievementsPanel);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Footer Panel
        JPanel footerPanel = new JPanel();
        footerPanel.setOpaque(false);
        footerPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Roboto", Font.BOLD, 16));
        backButton.addActionListener(e -> dispose());
        footerPanel.add(backButton);

        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    public static void main(String[] args) {
        // Example achievements for testing
        ArrayList<String> exampleAchievements = new ArrayList<>();
        exampleAchievements.add("Bingo!");
        exampleAchievements.add("Super Winner!");
        SwingUtilities.invokeLater(() -> new AchievementsGUI(exampleAchievements, "Player1").setVisible(true));
    }
}