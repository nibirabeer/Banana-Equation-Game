package com.perisic.banana.peripherals;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;

public class LeaderboardGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private String currentPlayer;

    public LeaderboardGUI(String player) {
        this.currentPlayer = player; // Store the current player's username
        setTitle("Leaderboard");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main Panel with Gradient Background
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, new Color(58, 123, 213), 
                                                           getWidth(), getHeight(), new Color(18, 33, 69));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        add(mainPanel);

        // Title
        JLabel title = new JLabel("🏆 Leaderboard", JLabel.CENTER);
        title.setFont(new Font("Roboto", Font.BOLD, 30));
        title.setForeground(Color.WHITE);
        title.setBorder(new EmptyBorder(10, 10, 20, 10));
        mainPanel.add(title, BorderLayout.NORTH);

        // Leaderboard Table
        String[] columnNames = {"Rank", "Player", "Score"};
        Object[][] data = loadLeaderboardData();
        JTable leaderboardTable = new JTable(data, columnNames);
        leaderboardTable.setFont(new Font("Roboto", Font.PLAIN, 16));
        leaderboardTable.setRowHeight(30);
        leaderboardTable.setShowGrid(false);
        leaderboardTable.setIntercellSpacing(new Dimension(0, 0));
        leaderboardTable.setFillsViewportHeight(true);
        leaderboardTable.getTableHeader().setFont(new Font("Roboto", Font.BOLD, 18));
        leaderboardTable.getTableHeader().setBackground(new Color(255, 195, 0));
        leaderboardTable.getTableHeader().setForeground(Color.BLACK);

        // Centering table content
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < leaderboardTable.getColumnCount(); i++) {
            leaderboardTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(leaderboardTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Back Button
        JButton backButton = new JButton("Back to Game");
        backButton.setFocusPainted(false);
        backButton.setFont(new Font("Roboto", Font.BOLD, 18));
        backButton.setBackground(new Color(34, 153, 84));
        backButton.setForeground(Color.WHITE);
        backButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        backButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backButton.addActionListener(e -> {
            this.dispose();
            SwingUtilities.invokeLater(() -> {
                GameGUI gameGUI = new GameGUI(currentPlayer); // Pass the current player back to the game
                gameGUI.setVisible(true);
            });
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.add(backButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
    }

    private Object[][] loadLeaderboardData() {
        Object[][] data = new Object[10][3]; // Assuming a maximum of 10 leaderboard entries
        try (Connection connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/banana_game", "root", "kalavala1");
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT username, score FROM leaderboard ORDER BY score DESC LIMIT 10")) {

            ResultSet resultSet = statement.executeQuery();
            int rank = 1;

            while (resultSet.next() && rank <= 10) {
                String player = resultSet.getString("username");
                int score = resultSet.getInt("score");
                data[rank - 1][0] = rank; // Rank
                data[rank - 1][1] = player; // Player Name
                data[rank - 1][2] = score; // Score
                rank++;
            }

            resultSet.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading leaderboard data. Please try again later.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return data;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LeaderboardGUI leaderboardGUI = new LeaderboardGUI("Player1"); // Example usage
            leaderboardGUI.setVisible(true);
        });
    }
}