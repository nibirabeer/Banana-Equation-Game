package com.perisic.banana.peripherals;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;

public class RegisterGUI extends JFrame {
    private static final long serialVersionUID = 1L;

    // UI Components
    private final JTextField txuser = new JTextField(15);
    private final JPasswordField pass = new JPasswordField(15);
    private final JTextField txemail = new JTextField(15);

    public RegisterGUI() {
        super("Register New Account");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Gradient Background Panel
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, new Color(123, 104, 238), getWidth(), getHeight(), new Color(240, 128, 128));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        backgroundPanel.setLayout(new BoxLayout(backgroundPanel, BoxLayout.Y_AXIS));
        backgroundPanel.setBorder(new EmptyBorder(20, 40, 20, 40));

        // Top Panel with Back to Home Button
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);

        JButton backToHomeButton = new JButton("Back to Home");
        backToHomeButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        backToHomeButton.setForeground(Color.WHITE);
        backToHomeButton.setBackground(new Color(0, 153, 76));
        backToHomeButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backToHomeButton.setFocusPainted(false);
        backToHomeButton.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        backToHomeButton.addActionListener(e -> {
            // Navigate back to Home page
            new LoginGUI().setVisible(true); // Assuming HomePage is the class for the Home screen
            dispose();
        });

        topPanel.add(backToHomeButton, BorderLayout.WEST);

        // Add top panel to the main panel
        backgroundPanel.add(topPanel);

        // Title Label
        JLabel titleLabel = new JLabel("Register New Account", JLabel.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 30));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        backgroundPanel.add(titleLabel);
        backgroundPanel.add(Box.createVerticalStrut(30));

        // Form Panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(6, 1, 10, 10));
        formPanel.setOpaque(false);

        // Username Field
        formPanel.add(createLabeledField("Username:", txuser));

        // Password Field
        formPanel.add(createLabeledField("Password:", pass));

        // Email Field
        formPanel.add(createLabeledField("Email:", txemail));

        // Register Button
        JButton bregister = new JButton("Register");
        bregister.setFont(new Font("SansSerif", Font.BOLD, 20));
        bregister.setForeground(Color.WHITE);
        bregister.setBackground(new Color(255, 69, 0));
        bregister.setFocusPainted(false);
        bregister.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bregister.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bregister.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Hover Effect for Button
        bregister.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                bregister.setBackground(new Color(220, 20, 60));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                bregister.setBackground(new Color(255, 69, 0));
            }
        });

        // Button Action
        bregister.addActionListener(this::registerUser);

        formPanel.add(bregister);
        backgroundPanel.add(formPanel);

        // Add components to frame
        add(backgroundPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    private JPanel createLabeledField(String labelText, JComponent field) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("SansSerif", Font.BOLD, 18));
        label.setForeground(Color.WHITE);
        panel.add(label, BorderLayout.NORTH);

        field.setPreferredSize(new Dimension(300, 30));
        field.setFont(new Font("SansSerif", Font.PLAIN, 16));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        panel.add(field, BorderLayout.CENTER);

        return panel;
    }

    private void registerUser(ActionEvent ae) {
        // Retrieve the user input
        String username = txuser.getText().trim();
        String password = String.valueOf(pass.getPassword()).trim();
        String email = txemail.getText().trim();

        // Validate input
        if (username.isEmpty() || password.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate Password
        if (!isValidPassword(password)) {
            JOptionPane.showMessageDialog(this, """
                    Password must be at least 8 characters long, 
                    contain at least one uppercase letter, one lowercase letter, 
                    one digit, and one special character.""", 
                    "Invalid Password", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate Email
        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(this, "Invalid email format. Please enter a valid email.", "Invalid Email", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Create RegisterData object and register the user
        RegisterData registerData = new RegisterData();
        boolean isSuccess = registerData.registerUser(username, password, email);

        // Display success or failure message
        if (isSuccess) {
            JOptionPane.showMessageDialog(this, "Registration Successful for " + username, "Success", JOptionPane.INFORMATION_MESSAGE);
            new LoginGUI().setVisible(true); // Redirect to login page
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Registration Failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean isValidPassword(String password) {
        // Regex for password validation
        String regex = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        return password.matches(regex);
    }

    private boolean isValidEmail(String email) {
        // Regex for email validation
        String regex = "^[\\w-\\.]+@[\\w-]+\\.[a-z]{2,}$";
        return email.matches(regex);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(RegisterGUI::new);
    }
}