package com.perisic.banana.peripherals;

import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;

public class RegisterData {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/banana_game"; // Database URL
    private static final String DB_USER = "root"; // MySQL username
    private static final String DB_PASSWORD = "kalavala1"; // MySQL password
    private Connection conn;

    /**
     * Constructor to initialize the MySQL connection.
     */
    public RegisterData() {
        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Database connection established successfully.");
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        }
    }

    /**
     * Authenticates a user by checking their username and password.
     * 
     * @param username The username to authenticate.
     * @param password The password to verify.
     * @return True if credentials are valid, otherwise false.
     */
    public boolean checkPassword(String username, String password) {
        String query = "SELECT password FROM users WHERE username = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String storedHash = rs.getString("password");
                return BCrypt.checkpw(password, storedHash);
            }
        } catch (SQLException e) {
            System.err.println("Error while verifying credentials: " + e.getMessage());
        }
        return false;
    }

    /**
     * Registers a new user in the database.
     * 
     * @param username The username for the new account.
     * @param password The password for the new account.
     * @param email    The email for the new account.
     * @return True if registration is successful, otherwise false.
     */
    public boolean registerUser(String username, String password, String email) {
        String query = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            pstmt.setString(2, hashedPassword);
            pstmt.setString(3, email);
            pstmt.executeUpdate();
            System.out.println("User registered successfully.");
            return true;
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) { // Duplicate entry error code
                System.err.println("Username already exists.");
            } else {
                System.err.println("Error while registering user: " + e.getMessage());
            }
        }
        return false;
    }

    /**
     * Deletes a user from the database.
     * 
     * @param username The username to delete.
     * @return True if the user was deleted, otherwise false.
     */
    public boolean deleteUser(String username) {
        String query = "DELETE FROM users WHERE username = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error while deleting user: " + e.getMessage());
        }
        return false;
    }

    /**
     * Resets a user's password.
     * 
     * @param username    The username to reset the password for.
     * @param newPassword The new password to set.
     * @return True if the password was updated, otherwise false.
     */
    public boolean resetPassword(String username, String newPassword) {
        String query = "UPDATE users SET password = ? WHERE username = ?";
        String hashedPassword = BCrypt.hashpw(newPassword, BCrypt.gensalt());
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, hashedPassword);
            pstmt.setString(2, username);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error while resetting password: " + e.getMessage());
        }
        return false;
    }

    /**
     * Closes the database connection.
     */
    public void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("Error while closing connection: " + e.getMessage());
        }
    }
}