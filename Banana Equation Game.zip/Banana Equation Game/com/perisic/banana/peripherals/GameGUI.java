package com.perisic.banana.peripherals;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.*;

import com.perisic.banana.engine.GameEngine;

public class GameGUI extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // UI Components
    private JLabel questArea;
    private JLabel timerLabel;
    private JLabel scoreLabel;
    private JLabel messageLabel;

    private Timer gameTimer;
    private GameEngine myGame;

    // Game State Variables
    private int timeLeft = 120; // Initial time for questions
    private int consecutiveWins = 0;
    private int questionCounter = 1; // Tracks the current question number
    private long gameStartTime;

    private static final int INITIAL_STAGE_QUESTIONS = 5;
    private ArrayList<String> achievements = new ArrayList<>();
    private final String currentPlayer;

    public GameGUI(String player) {
        super("What is the Missing Value? 🌟");
        this.currentPlayer = player;
        initializeGame();
    }

    /**
     * Initializes the game components and UI.
     */
    private void initializeGame() {
        setSize(800, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with gradient background
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, new Color(220, 200, 255), 0, getHeight(), new Color(150, 100, 255));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        // Top panel with navbar and info
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(createNavBar(), BorderLayout.NORTH);
        topPanel.add(createInfoPanel(), BorderLayout.SOUTH);

        // Center panel for the game question
        JPanel centerPanel = createQuestionPanel();

        // Bottom panel with answer buttons
        JPanel buttonPanel = createButtonPanel();

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);

        myGame = new GameEngine(currentPlayer);
        questArea.setIcon(new ImageIcon(myGame.nextGame()));

        startTimer();
    }

    /**
     * Creates the navigation bar with action buttons.
     */
    private JPanel createNavBar() {
        JPanel navBar = new JPanel(new FlowLayout(FlowLayout.CENTER));
        navBar.setBackground(new Color(162, 105, 238));
        navBar.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        navBar.add(createNavButton("Skip", "Skip"));
        navBar.add(createNavButton("Leaderboard", null, e -> showLeaderboard()));
        navBar.add(createNavButton("Achievements", null, e -> showAchievements()));
        navBar.add(createNavButton("Quit", "Quit"));

        return navBar;
    }

    /**
     * Creates a single navigation button with hover effects.
     */
    private JButton createNavButton(String text, String actionCommand) {
        return createNavButton(text, actionCommand, this);
    }

    private JButton createNavButton(String text, String actionCommand, ActionListener listener) {
        JButton button = new JButton(text);
        button.setActionCommand(actionCommand);
        button.addActionListener(listener);
        button.setFocusPainted(false);
        button.setFont(new Font("Roboto", Font.BOLD, 14));
        button.setBackground(new Color(162, 105, 238));  // Soft purple to match the theme
        button.setForeground(Color.WHITE);  // Text color is white for contrast
        button.setBorder(BorderFactory.createLineBorder(new Color(150, 100, 255), 2));  // Slightly thicker border
        button.setOpaque(true);
        button.setPreferredSize(new Dimension(120, 40));  // A bit larger for better usability
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));  // Pointer cursor for better UX

        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(140, 85, 255));  // Lighter shade of purple
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(162, 105, 238));  // Original soft purple
            }
        });

        return button;
    }

    /**
     * Creates the information panel with timer, score, and message labels.
     */
    private JPanel createInfoPanel() {
        JPanel infoPanel = new JPanel(new GridLayout(3, 1));
        infoPanel.setBackground(new Color(224, 215, 236));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        timerLabel = createInfoLabel("Time Left: " + timeLeft + " seconds");
        scoreLabel = createInfoLabel("Score: 0");
        messageLabel = createInfoLabel("Hurry up, the game started!");

        infoPanel.add(timerLabel);
        infoPanel.add(scoreLabel);
        infoPanel.add(messageLabel);

        return infoPanel;
    }

    private JLabel createInfoLabel(String text) {
        JLabel label = new JLabel(text, JLabel.CENTER);
        label.setFont(new Font("Roboto", Font.BOLD, 16));
        return label;
    }

    /**
     * Creates the panel for displaying the game question.
     */
    private JPanel createQuestionPanel() {
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(Color.WHITE);

        questArea = new JLabel();
        questArea.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(questArea);

        return centerPanel;
    }

    /**
     * Creates the panel with answer buttons (0-9).
     */
    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Color.WHITE);  // Make sure the background is white for contrast

        for (int i = 0; i < 10; i++) {
            JButton btn = new JButton(String.valueOf(i));
            btn.setFont(new Font("Roboto", Font.BOLD, 25));
            btn.setFocusPainted(false);
            btn.setBackground(new Color(200, 230, 250));  // Soft blue
            btn.setForeground(Color.DARK_GRAY);  // Text color for better contrast
            btn.setBorder(BorderFactory.createLineBorder(new Color(100, 150, 200), 2));  // Slightly thicker border
            btn.setOpaque(true);
            btn.setPreferredSize(new Dimension(60, 60));  // Bigger buttons for better clickability
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            // Add hover effect
            btn.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    btn.setBackground(new Color(180, 220, 240));  // Lighten on hover
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    btn.setBackground(new Color(200, 230, 250));  // Original soft blue
                }
            });

            buttonPanel.add(btn);
        }

        return buttonPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if ("Skip".equals(command)) {
            skipQuestion();
        } else if ("Quit".equals(command)) {
            quitGame();
        } else {
            try {
                handleAnswer(Integer.parseInt(command));
            } catch (NumberFormatException ex) {
                System.err.println("Invalid input: " + command);
            }
        }
    }

    private void handleAnswer(int solution) {
        boolean correct = myGame.checkSolution(solution);
        scoreLabel.setText("Score: " + myGame.getScore());

        if (correct) {
            messageLabel.setText("🎉 Correct Answer!");
            consecutiveWins++;
            if (consecutiveWins == 5) achievements.add("Bingo!");
            nextQuestion();
        } else {
            messageLabel.setText("❌ Incorrect! Try again.");
            consecutiveWins = 0;
        }
    }

    private void startTimer() {
        gameTimer = new Timer(1000, e -> {
            timeLeft--;
            timerLabel.setText("Time Left: " + timeLeft + " seconds");
            if (timeLeft <= 0) nextQuestion();
        });
        gameTimer.start();
    }

    private void nextQuestion() {
        timeLeft = questionCounter <= INITIAL_STAGE_QUESTIONS ? 120 : 10;
        questArea.setIcon(new ImageIcon(myGame.nextGame()));
        questionCounter++;
    }

    private void skipQuestion() {
        nextQuestion();
    }

    private void quitGame() {
        gameTimer.stop();
        dispose();
        SwingUtilities.invokeLater(() -> new LoginGUI().setVisible(true));
    }

    private void showLeaderboard() {
        JOptionPane.showMessageDialog(this, "Leaderboard functionality is under construction!", "Leaderboard", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAchievements() {
        StringBuilder achievementsText = new StringBuilder("<html><h3>Achievements</h3>");
        if (achievements.isEmpty()) achievementsText.append("<p>No achievements unlocked yet.</p>");
        else achievements.forEach(a -> achievementsText.append("<p>• ").append(a).append("</p>"));
        achievementsText.append("</html>");

        JOptionPane.showMessageDialog(this, achievementsText.toString(), "Achievements", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GameGUI("Player1").setVisible(true));
    }
}