package com.perisic.banana.peripherals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class LoginGUI extends JFrame {

    private static final long serialVersionUID = -6921462126880570161L;

    JButton blogin = new JButton("Login");
    JButton bregister = new JButton("Register"); // Registration Button
    JTextField txuser = new JTextField(15);
    JPasswordField pass = new JPasswordField(15);
    JLabel titleLabel = new JLabel("Welcome to the Banana Equation Game!");
    JLabel userLabel = new JLabel("Username:");
    JLabel passLabel = new JLabel("Password:");

    RegisterData rdata = new RegisterData(); // Use RegisterData for authentication

    public LoginGUI() {
        super("Login Authentication");
        setSize(1080, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(224, 215, 236));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // Main panel layout
        panel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        // Custom Fonts
        try {
            Font customFont = Font.createFont(Font.TRUETYPE_FONT, new File("fonts/Bokor-Regular.ttf")).deriveFont(16f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(customFont);

            // Custom title font (adjust size here)
            Font titleFont = customFont.deriveFont(40f); // Title font size is set to 30
            titleLabel.setFont(titleFont);

            // Custom font for username and password labels
            Font labelFont = customFont.deriveFont(18f); // Username/Password font size set to 18
            userLabel.setFont(labelFont);
            passLabel.setFont(labelFont);
            blogin.setFont(customFont);
            bregister.setFont(customFont); // Set font for register button
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Title Label with Icon
        titleLabel.setForeground(new Color(255, 66, 0));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Resize the icon
        ImageIcon originalIcon = new ImageIcon("Icons/bananas.png");
        Image scaledImage = originalIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH); // Resize
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        // Set the resized icon
        titleLabel.setIcon(scaledIcon);

        titleLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        titleLabel.setVerticalTextPosition(SwingConstants.BOTTOM);
        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(20));

        // Username Field
        userLabel.setForeground(Color.BLACK);
        userLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(userLabel);
        panel.add(Box.createVerticalStrut(5));
        txuser.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        txuser.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txuser.setForeground(Color.BLACK);
        panel.add(txuser);
        panel.add(Box.createVerticalStrut(15));

        // Password Field
        passLabel.setForeground(Color.BLACK);
        passLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(passLabel);
        panel.add(Box.createVerticalStrut(15));
        pass.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        pass.setFont(new Font("SansSerif", Font.PLAIN, 14));
        pass.setForeground(Color.BLACK);
        panel.add(pass);
        panel.add(Box.createVerticalStrut(10));

        // Panel for buttons (Login and Register)
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); // Align buttons horizontally
        buttonPanel.setBackground(new Color(224, 215, 236)); // Same background as the main panel

        // Login Button
        blogin.setFont(new Font("SansSerif", Font.BOLD, 30));
        blogin.setForeground(Color.BLACK);
        blogin.setBackground(new Color(141, 114, 176));
        blogin.setFocusPainted(false);
        blogin.setBorder(BorderFactory.createLineBorder(new Color(141, 114, 176), 3));
        blogin.setOpaque(true);
        blogin.setPreferredSize(new Dimension(200, 60)); // Adjust size as needed
        blogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        buttonPanel.add(blogin);

        // Register Button
        bregister.setFont(new Font("SansSerif", Font.BOLD, 30));
        bregister.setForeground(Color.BLACK);
        bregister.setBackground(new Color(141, 114, 176));
        bregister.setFocusPainted(false);
        bregister.setBorder(BorderFactory.createLineBorder(new Color(141, 114, 176), 3));
        bregister.setOpaque(true);
        bregister.setPreferredSize(new Dimension(200, 60)); // Adjust size as needed
        bregister.setCursor(new Cursor(Cursor.HAND_CURSOR));
        buttonPanel.add(bregister);

        panel.add(buttonPanel);

        getContentPane().add(panel);
        setVisible(true);

        actionlogin();
        actionRegister();
    }

    public void actionlogin() {
        blogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String puname = txuser.getText();
                String ppaswd = String.valueOf(pass.getPassword());

                // Authenticate using RegisterData
                if (rdata.checkPassword(puname, ppaswd)) {
                    GameGUI theGame = new GameGUI(puname);
                    theGame.setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "❌ Wrong Username or Password", "Login Error",
                            JOptionPane.ERROR_MESSAGE);
                    txuser.setText("");
                    pass.setText("");
                    txuser.requestFocus();
                }
            }
        });
    }

    // Action for Register Button
    public void actionRegister() {
        bregister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                RegisterGUI registerPage = new RegisterGUI(); // Open the registration form
                registerPage.setVisible(true); // Make the registration form visible
                dispose(); // Close the login form
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginGUI::new);
    }
}